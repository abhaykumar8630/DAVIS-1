# Program to check if a number is a natural number or not
# Enter a number
num = int(input("Enter a number: "))
# Verification of natural number
if num > 0:
    print(num, " is a natural number")
else:
    print(num, " is not a natural number")
